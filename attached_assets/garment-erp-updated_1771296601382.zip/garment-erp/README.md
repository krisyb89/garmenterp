# 📦 Garment Trade & Manufacturing ERP

A purpose-built ERP system for garment sourcing, development, manufacturing, and trading companies. Manages the complete lifecycle from customer development requests (SRS) through production, invoicing, and financial reconciliation.

## Tech Stack

- **Frontend**: Next.js 14 + React 18 + Tailwind CSS
- **Backend**: Next.js API Routes
- **Database**: PostgreSQL + Prisma ORM
- **Auth**: JWT with HTTP-only cookies

---

## 🚀 Deploy on Replit (Step-by-Step)

### Step 1: Create a New Repl
1. Go to [replit.com](https://replit.com) and create a new Repl
2. Choose **"Import from GitHub"** or **"Node.js"** template
3. If importing, upload all these files to the Repl

### Step 2: Set Up PostgreSQL Database
1. In your Repl, go to the **Tools** panel → **Database**
2. Click **"PostgreSQL"** to provision a free PostgreSQL database
3. Replit will auto-set `DATABASE_URL` in your environment

**OR** if using an external database (Neon, Supabase, Railway):
1. Go to **Secrets** (lock icon in sidebar)
2. Add `DATABASE_URL` with your PostgreSQL connection string:
   ```
   postgresql://user:password@host:5432/garment_erp?schema=public
   ```

### Step 3: Set JWT Secret
1. In **Secrets**, add:
   - Key: `JWT_SECRET`
   - Value: Any long random string (e.g., `my-super-secret-key-change-this-123`)

### Step 4: Install & Initialize
Open the **Shell** tab and run these commands in order:

```bash
# 1. Install dependencies
npm install

# 2. Generate Prisma client
npx prisma generate

# 3. Push schema to database (creates all tables)
npx prisma db push

# 4. Seed with sample data
node prisma/seed.js

# 5. Start the app
npm run dev
```

### Step 5: Login
Once the app starts, open the webview and login with:
- **Admin**: `admin@garment-erp.com` / `admin123`
- **Merchandiser**: `merch@garment-erp.com` / `merch123`

---

## 📁 Project Structure

```
garment-erp/
├── prisma/
│   ├── schema.prisma      # Complete database schema (30+ models)
│   └── seed.js            # Sample data seeder
├── src/
│   ├── app/
│   │   ├── api/           # All API routes
│   │   │   ├── auth/          # Login, logout, session
│   │   │   ├── customers/     # Customer CRUD
│   │   │   ├── srs/           # Development requests
│   │   │   ├── styles/        # Style master
│   │   │   ├── purchase-orders/ # Customer POs
│   │   │   ├── suppliers/     # Supplier management
│   │   │   ├── materials/     # Material master
│   │   │   ├── factories/     # Factory management
│   │   │   ├── production-orders/ # Production tracking
│   │   │   ├── samples/       # Sample management
│   │   │   ├── approvals/     # Lab dip, fabric, trim approvals
│   │   │   ├── supplier-pos/  # Supplier purchase orders
│   │   │   ├── shipments/     # Shipment tracking
│   │   │   ├── invoices/      # Customer invoicing
│   │   │   ├── order-costs/   # Order P&L tracking
│   │   │   └── dashboard/     # Dashboard stats
│   │   ├── (dashboard)/   # Dashboard pages (all modules)
│   │   └── login/         # Login page
│   ├── components/        # Reusable UI components
│   └── lib/               # Utilities (prisma, auth, helpers)
├── .replit                # Replit run configuration
├── replit.nix             # Nix packages for Replit
└── package.json
```

## 🔧 Modules

| Module | Description |
|--------|-------------|
| **Customers** | Customer profiles, payment terms, currency settings |
| **SRS / Dev Requests** | Development request intake with costing sheets |
| **Styles** | Style master with BOM, tech packs, categories |
| **Samples** | Multi-stage tracking (Proto, Fit, PP, TOP) with revision history |
| **Approvals** | Lab dip, fabric, trim, strike-off approval tracking |
| **Purchase Orders** | Full PO with size-color matrix, line items, status workflow |
| **Suppliers** | Supplier profiles by type (mill, trim, CMT, etc.) |
| **Materials** | Material master with multi-supplier pricing |
| **Supplier POs** | Procurement orders linked to customer POs |
| **Factories** | In-house and external factory management (any country) |
| **Production** | Production orders with stage pipeline tracking |
| **QC / Inspection** | AQL-based inspection with defect tracking |
| **Shipments** | Full shipment lifecycle with ROG date → payment trigger |
| **Invoices** | Auto-generated from PO, payment recording, AR tracking |
| **Order P&L** | Per-order cost tracking and profitability analysis |
| **Payments / AR** | Accounts receivable dashboard with aging |

## 🔑 Default Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@garment-erp.com | admin123 |
| Merchandiser | merch@garment-erp.com | merch123 |

## 📝 Key Workflow

```
Customer sends SRS → Costing → Quote → PO Received →
  ├→ Create Styles & BOM
  ├→ Sample Development (Fit → PP → TOP)
  ├→ Material Approvals (Lab Dip, Fabric, Trim)
  ├→ Supplier POs (Material Procurement)
  ├→ Production Order (Assign Factory)
  │     └→ Cutting → Sewing → Washing → QC → Packing
  ├→ Packing List (cross-check with PO)
  ├→ Shipment (track ETD/ETA/ROG)
  ├→ Invoice (auto from PO + Packing List)
  │     └→ Due Date = ROG + Payment Terms
  └→ Order P&L (Revenue - All Actual Costs)
```
