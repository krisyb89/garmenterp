# Run Garment ERP Locally (Before Deploying to Replit)

## Prerequisites

You need **three things** on your laptop:

1. **Node.js 18+** — check with `node --version`
   - Install from https://nodejs.org or via `brew install node` (Mac) / `winget install OpenJS.NodeJS.LTS` (Windows)

2. **PostgreSQL 14+** — check with `psql --version`
   - **Mac**: `brew install postgresql@16 && brew services start postgresql@16`
   - **Windows**: Download from https://www.postgresql.org/download/windows/
   - **Or use Docker**: `docker run -d --name erp-db -e POSTGRES_PASSWORD=postgres -p 5432:5432 postgres:16`

3. **Git** (optional, for version control)

---

## Step-by-Step Setup

### 1. Unzip and enter the project

```bash
unzip garment-erp.zip
cd garment-erp
```

### 2. Install dependencies

```bash
npm install
```

### 3. Create a local database

If using native Postgres:
```bash
createdb garment_erp
```

If using Docker (already created above), the default `postgres` database works, or:
```bash
docker exec -it erp-db psql -U postgres -c "CREATE DATABASE garment_erp;"
```

### 4. Create your `.env.local` file

```bash
cp .env.local.example .env.local
```

Then edit `.env.local`:
```env
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/garment_erp"
JWT_SECRET="any-random-string-for-local-dev"
```

**Adjust the connection string** if your Postgres has a different username/password/port.
Common patterns:
- Mac Homebrew (no password): `postgresql://localhost:5432/garment_erp`
- Mac Homebrew (with user): `postgresql://your_username@localhost:5432/garment_erp`
- Docker: `postgresql://postgres:postgres@localhost:5432/garment_erp`
- Windows default: `postgresql://postgres:your_password@localhost:5432/garment_erp`

### 5. Generate Prisma client & run migrations

```bash
npx prisma generate
npx prisma migrate deploy
```

You should see:
```
2 migrations applied:
  0001_initial
  0002_decimal_precision_standardization
```

### 6. Seed demo data

```bash
ALLOW_SEED=true npm run seed
```

On Windows (PowerShell):
```powershell
$env:ALLOW_SEED="true"; npm run seed
```

On Windows (cmd):
```cmd
set ALLOW_SEED=true && npm run seed
```

### 7. Start the dev server

```bash
npm run dev
```

App runs at **http://localhost:3000**

### 8. Login

| Role | Email | Password |
|------|-------|----------|
| Admin | `admin@garment-erp.com` | `admin123` |
| Merchandiser | `merch@garment-erp.com` | `merch123` |

---

## Test the Samples & Approvals Flow

### Quick test path:

1. **Login as admin** → Dashboard shows pending samples/approvals counts

2. **Go to Styles** → Open any style → You'll see:
   - "Samples" section with **+ Add Sample** button
   - "Approvals" section with **+ Add Approval** button
   - "Style Images" section with image uploader

3. **Create a sample** (click + Add Sample):
   - Select stage (PROTO, FIT, PP, etc.)
   - Add size, fabric, courier, tracking info
   - Upload sample photos (drag or click the 📷 tile)
   - Submit → redirects to samples list

4. **Open the sample** (click Open →):
   - See the detail page with status dropdown and quick action buttons
   - Click **Start** → status changes to IN_PROGRESS
   - Click **Mark Submitted** → status changes to SUBMITTED, date auto-fills
   - Click **Approve** or **Reject** → final status set
   - Edit any field and click **Save Changes**
   - Upload more photos in the side panel

5. **Create an approval** (from style detail → + Add Approval):
   - Select type (LAB_DIP, FABRIC, TRIM, etc.)
   - Optionally link a material from the material library
   - Add reference (Pantone #), supplier name
   - Upload swatch photos
   - Submit

6. **Open the approval** (click Open →):
   - Same pattern: quick action buttons for status transitions
   - PENDING → Mark Submitted → Approve / Reject / Request Resubmit
   - Edit reference, supplier, dates, comments
   - Upload/remove photos

7. **Check filters**: Both list pages have filter buttons by stage/type and status

8. **Check RBAC**: Login as `merch@garment-erp.com` — can access samples/approvals but NOT invoices or order costs (403).

---

## File Upload Testing

Uploaded images go to `public/uploads/` on your local filesystem.
- Supported images: `.jpg`, `.jpeg`, `.png`, `.webp`, `.gif`
- Supported docs: `.pdf`, `.xlsx`, `.xls`, `.doc`, `.docx`, `.ai`, `.psd`
- Max size: 10MB per file

---

## Useful Dev Commands

| Command | What it does |
|---------|-------------|
| `npm run dev` | Start dev server with hot reload (port 3000) |
| `npm run build` | Production build (catches build errors) |
| `npm start` | Start production server (run `build` first) |
| `npx prisma studio` | Visual database browser at localhost:5555 |
| `npx prisma migrate dev` | Create new migration after schema changes |
| `npx prisma migrate deploy` | Apply pending migrations |
| `npx prisma generate` | Regenerate Prisma client after schema changes |

### Prisma Studio (highly recommended)

```bash
npx prisma studio
```

Opens a visual DB browser at **http://localhost:5555** — browse all tables, view/edit records, check relationships. Great for verifying seed data and testing.

---

## Troubleshooting

**"Cannot find module '@prisma/client'"**
→ Run `npx prisma generate`

**"Connection refused" or database errors**
→ Check Postgres is running: `pg_isready` or `docker ps`
→ Verify `DATABASE_URL` in `.env.local` matches your Postgres credentials

**"Missing JWT_SECRET"**
→ Make sure `.env.local` has `JWT_SECRET=` set to any string

**Build fails with "Module not found"**
→ Run `npm install` again

**Port 3000 already in use**
→ Kill it: `lsof -ti:3000 | xargs kill` (Mac/Linux) or change port: `PORT=3001 npm run dev`

---

## When Ready to Deploy to Replit

1. Push your code to a GitHub repo (or zip and import)
2. In Replit: Import repo → Enable PostgreSQL → Set `JWT_SECRET` in Secrets
3. Replit auto-handles the rest via `.replit` config:
   - Build: `npm install && prisma generate && prisma migrate deploy && npm run build`
   - Run: `npm start`
4. One-time seed: Set `ALLOW_SEED=true` in Secrets → run `npm run seed` in Shell → remove the secret
