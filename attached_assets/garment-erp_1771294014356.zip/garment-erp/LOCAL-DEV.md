# Local Development Setup

Run this project on your laptop before deploying to Replit.

## Prerequisites

- **Node.js 18+** — check with `node -v`
- **PostgreSQL 14+** — local instance or Docker
- **npm** (comes with Node)

## Option A: PostgreSQL via Docker (easiest)

```bash
# Start a local Postgres container
docker run --name garment-pg -e POSTGRES_PASSWORD=localdev -e POSTGRES_DB=garment_erp -p 5432:5432 -d postgres:16

# Your connection string:
# postgresql://postgres:localdev@localhost:5432/garment_erp
```

## Option B: Local PostgreSQL

If you already have Postgres installed, create a database:

```bash
createdb garment_erp
# Connection string: postgresql://your_user:your_password@localhost:5432/garment_erp
```

## Setup Steps

```bash
# 1. Unzip and enter the project
unzip garment-erp.zip
cd garment-erp

# 2. Install dependencies
npm install

# 3. Create .env file (copy from example, then edit)
cp .env.example .env
```

Edit `.env` with your values:

```env
DATABASE_URL="postgresql://postgres:localdev@localhost:5432/garment_erp"
JWT_SECRET="any-random-string-for-local-dev"
```

```bash
# 4. Generate Prisma client
npx prisma generate

# 5. Run all migrations (creates tables)
npx prisma migrate deploy

# 6. Seed sample data
ALLOW_SEED=true npm run seed

# 7. Start dev server
npm run dev
```

Open **http://localhost:3000**

## Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@garment-erp.com | admin123 |
| Merchandiser | merch@garment-erp.com | merch123 |

## Useful Commands

```bash
# View database in browser
npx prisma studio

# Create a new migration after schema changes
npx prisma migrate dev --name my_change_name

# Reset database (drops all data!)
npx prisma migrate reset

# Production build (test before deploying)
npm run build && npm start
```

## Testing the New Features

### File Uploads
1. Go to SRS → New SRS
2. Upload images in the "Reference Images" section
3. Attach PDFs/docs in the "Attachments" section
4. Save — images and files persist
5. Also works on Style → New Style (images section)

### Samples
1. Go to Samples → + New Sample
2. Select a style, stage, upload photos
3. Open the sample detail page
4. Use quick-action buttons: Start → Mark Submitted → Approve/Reject
5. Edit dates, comments, tracking info

### Approvals
1. Go to Approvals → + New Approval
2. Select a style, type (Lab Dip, Fabric, etc.), upload swatch photos
3. Open detail — Approve / Reject / Request Resubmit

### Custom PO Sizes
1. Go to Purchase Orders → New Purchase Order
2. See the "Size Columns" editor with S/M/L/XL default
3. Click "Numeric (28-38)" preset — columns change to 28/30/32/34/36/38
4. Type "3XL" in the input and click Add — new column appears
5. Remove a size by clicking ✕ on its pill
6. All line items update to match the current size columns

### Dynamic Size Display
1. Open an existing PO detail — size columns auto-detected from data
2. Open a Packing List detail — summary table columns extracted from carton data

## Deploy to Replit

When satisfied locally:

1. Push to GitHub (or zip and import to Replit)
2. In Replit, add these Secrets:
   - `JWT_SECRET` = a strong random string
   - `DATABASE_URL` = auto-provided by Replit Postgres
   - `ALLOW_SEED` = `true` (one-time, then remove)
3. The `.replit` file handles build + deploy automatically
