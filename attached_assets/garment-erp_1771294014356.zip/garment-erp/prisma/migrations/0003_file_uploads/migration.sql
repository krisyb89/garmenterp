-- Add image and file attachment fields
ALTER TABLE "srs" ADD COLUMN IF NOT EXISTS "imageUrls" JSONB;
ALTER TABLE "srs" ADD COLUMN IF NOT EXISTS "attachments" JSONB;
ALTER TABLE "styles" ADD COLUMN IF NOT EXISTS "imageUrls" JSONB;
